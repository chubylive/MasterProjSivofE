#/bin/bash 

echo "programming fpga for computational 3"
cd /lib/firmware ; echo m_3_final.bin > /sys/class/fpga_manager/fpga0/firmware